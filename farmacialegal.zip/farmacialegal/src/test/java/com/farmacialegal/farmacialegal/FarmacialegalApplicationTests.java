package com.farmacialegal.farmacialegal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmacialegalApplicationTests {

	@Test
	void contextLoads() {
	}

}
